
public class Ejercicio3 {

	public static void main(String[] args) {

	    String nombre = "David Reyes Padilla";
	    String direccion = "Avenida de las Ciencias,55,6ºA";
	    String telefono = "601 40 35 20";
	    
	    System.out.println(nombre);
	    System.out.println(direccion);
	    System.out.println(telefono);

	}

}
