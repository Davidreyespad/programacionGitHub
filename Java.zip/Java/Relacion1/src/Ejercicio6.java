
public class Ejercicio6 {

	public static void main(String[] args) {

		final double IVA = 0.18;
		int producto=300;
		
		double resultado=producto + IVA;
		
		System.out.println("El IVA del producto es: " + resultado);

	}

}
