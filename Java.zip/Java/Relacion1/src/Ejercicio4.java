
public class Ejercicio4 {

	public static void main(String[] args) {
	
	    int euros = 1;
	    double pesetas = euros * 166.386;
	    
	    System.out.println(euros + " euros son " + pesetas + " pesetas.");



	}

}
