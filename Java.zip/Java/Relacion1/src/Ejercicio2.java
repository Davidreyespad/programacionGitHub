
public class Ejercicio2 {

	public static void main(String[] args) {
		
			    String nombre = "David Reyes Padilla";
			    System.out.println(nombre);
			
	}

}
