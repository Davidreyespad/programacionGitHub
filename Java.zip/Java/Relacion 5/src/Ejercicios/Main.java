package Ejercicios;

public class Main {

    public static void main(String[] args) {
        frmCreaSopaLetras frm = new frmCreaSopaLetras();
        frm.setVisible(true);
    }
    //Notas: Error al agregar palabra de 1 letra
}
