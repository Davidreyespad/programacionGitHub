
 public class Ejercicio1 { 
	
	
  public static void main(String[] args) {
	  
    int x = 144;
    int y = 999;
    
    int suma = x+y;
    int resta = x-y;
    int multiplicacion = x*y;
    int division = x/y;
    
     System.out.println("El resultado de la suma es:" + suma);
     System.out.println("El resultado de la resta es: " + resta);
     System.out.println ("El resultado de la multiplicacion es:" + multiplicacion);
     System.out.println("El resultado de la division es: " + division);

  }
 
}