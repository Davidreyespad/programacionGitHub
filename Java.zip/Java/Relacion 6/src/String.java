
public class String {

}
