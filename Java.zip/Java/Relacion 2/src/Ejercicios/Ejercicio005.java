package Ejercicios;

public class Ejercicio005 {

	public static void main(String[] args) {
	    
	    int i = 320;
	    
	    while(i >= 160) {
	        System.out.println(i);
	        i-=20;
	    }
	  }
	}
