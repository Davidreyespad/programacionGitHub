package Ejercicios;

public class Ejercicio002 {

	public static void main(String[] args) {
		
	
	    int num = 0;
	    
	    while(num <= 100) {
	      System.out.println(num);
	      num+=5;

	}

	}
}