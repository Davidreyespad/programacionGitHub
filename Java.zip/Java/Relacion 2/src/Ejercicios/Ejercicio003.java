package Ejercicios;

public class Ejercicio003 {

	public static void main(String[] args) {
	
	    
	    int num = 0;
	    
	    do {
	      System.out.println(num);
	      num+=5;
	    } while(num <= 100);
	}

}
