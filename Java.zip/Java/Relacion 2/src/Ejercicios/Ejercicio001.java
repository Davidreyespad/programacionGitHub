package Ejercicios;

public class Ejercicio001 {

	public static void main(String[] args) {
		
	    
	    for (int num= 5; num<= 100; num+=5) {
	      System.out.println(num);

		}

	}

}
